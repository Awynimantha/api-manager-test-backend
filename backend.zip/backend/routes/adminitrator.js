let express = require('express');
let adminRouter = express.Router();

//cusomer route hadnling

adminRouter.get('/api/test',async(req,res,next)=>{
    res.send("test")
})
adminRouter.get('/api/',async(req,res,next)=>{
    res.send("root")
})

module.exports = adminRouter;